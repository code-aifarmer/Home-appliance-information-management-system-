#include "mainwindow15.h"
#include "ui_mainwindow15.h"
#include "smtp.h"
#include "widget.h"
#include "QMessageBox"
#include "mainwindow.h"
#include<QFile>
#include<QFileDialog>
#include<QDir>
#include<QTextStream>
#include <QPlainTextEdit>
#include <QTextStream>>
MainWindow15::MainWindow15(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow15)
{
    ui->setupUi(this);
    QIcon icon("C:/Users/12234/Desktop/s.jpg");
    setWindowIcon(icon);
    setWindowTitle(QStringLiteral("家电信息管理系统"));
}

MainWindow15::~MainWindow15()
{
    delete ui;
}
//wavqnexaaypbjici  POP3/SMTP服务密码
//eouidnvznwawhehc  IMAP/SMTP服务密码
void MainWindow15::on_pushButton_2_clicked()
{
    /*
    Smtp *sendmail=new Smtp("smtp.qq.com","1223419806@qq.com","wavqnexaaypbjici");
    if(sendmail->Send("1223419806@qq.com","11","11"))
     {
          if(sendmail->PutSendLine())
     {
             qDebug() <<"发送成功.";
     }
          else
     {
             qDebug() << "发送失败.";
     }
     }
     */
    rmail=ui->lineEdit_2->text();
    Widget *s=new Widget();

}


void MainWindow15::on_pushButton_clicked()
{
    bool judge=0;
        if(ui->lineEdit_5->text()!=yanzheng)
        {
           QMessageBox::about(NULL,"提示","验证码有误,请重新获取验证码!");
           yanzheng="";
        }
        if(ui->lineEdit_3->text()!=ui->lineEdit_4->text())
        {
            QMessageBox::about(NULL,"提示","两次输入的密码不一致");
            judge=1;

        }
        if(ui->lineEdit_3->text()==ui->lineEdit_4->text())judge=0;
        if(ui->lineEdit_3->text()==ui->lineEdit_4->text()&&ui->lineEdit_5->text()==yanzheng&&judge==0)
        {
            QString filePath = "C:/Users/12234/Documents/01/sum_info/";
            filePath=filePath+ui->lineEdit->text()+"/acount_info.txt";
            QFile f(filePath);
            if(!f.open(QIODevice::WriteOnly | QIODevice::ReadOnly|QIODevice::Text|QIODevice::Append))
            {
             QMessageBox::about(NULL, "提示", "文件异常");
                return;
            }
            QTextStream txtOutput(&f);

            QString info=f.readAll();

            QStringList strList;
            QString s1=ui->lineEdit->text();
            QString s2=ui->lineEdit_3->text();
            txtOutput <<"%"<<s1<<"#"<<s2<<"%";
            QMessageBox::about(NULL,"提示","密码修改成功！");
        }
}


void MainWindow15::on_pushButton_3_clicked()
{
    (new MainWindow())->show();
    this->hide();
}

