#include "connection.h"
#include <QtSql>
connection::connection()
{

}
