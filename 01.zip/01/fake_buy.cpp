#include "fake_buy.h"
#include "ui_fake_buy.h"
#include "QMessageBox"
#include "air_conditioner.h"
fake_buy::fake_buy(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::fake_buy)
{
    ui->setupUi(this);
    QIcon icon("C:/Users/12234/Desktop/s.jpg");
    setWindowIcon(icon);
    setWindowTitle(QStringLiteral("家电信息管理系统"));
}

fake_buy::~fake_buy()
{
    delete ui;
}

void fake_buy::on_pushButton_2_clicked()
{
    QMessageBox::about(NULL,"提示","感谢您的购买");

}


void fake_buy::on_pushButton_3_clicked()
{
    (new Air_conditioner())->show();
    this->hide();
}

